package com.example.demo.dto;

public class PdfResponse {

    private String userId;

    private String tId;

    public PdfResponse() {

    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String gettId() {
        return tId;
    }

    public void settId(String tId) {
        this.tId = tId;
    }

}
